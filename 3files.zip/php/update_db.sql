ALTER TABLE `users` ADD `device_fingerprint` VARCHAR(255) NULL AFTER `password`;
