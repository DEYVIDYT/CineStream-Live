package com.cinestream.live;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class ChannelsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // This is a dummy activity to resolve build issues.
        // It should not be used.
        finish(); // Finish immediately if ever started.
    }
}
